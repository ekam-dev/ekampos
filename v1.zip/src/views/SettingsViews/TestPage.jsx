import React, { useContext, useEffect, useRef, useState } from 'react'
import Page from "../../components/Page";

export default function TestPage() {

    return (
        <Page className='px-4 py-3 flex flex-col min-h-0'>
            <div>
                <h1>pax</h1>
            </div>
        </Page>
    )
    

}